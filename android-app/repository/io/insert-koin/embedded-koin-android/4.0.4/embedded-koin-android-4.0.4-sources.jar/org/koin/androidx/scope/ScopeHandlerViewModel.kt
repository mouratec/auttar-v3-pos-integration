/*
 * Copyright 2017-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package embedded.koin.androidx.scope

import androidx.lifecycle.ViewModel
import embedded.koin.core.scope.Scope

/**
 * Scope support for ViewModel
 */
class ScopeHandlerViewModel : ViewModel() {

    var scope: Scope? = null

    override fun onCleared() {
        super.onCleared()
        scope?.apply {
            if (isNotClosed()) {
                logger.debug("Closing scope $scope")
                close()
            }
        }
        scope = null
    }
}
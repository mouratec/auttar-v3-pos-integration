/*
 * Copyright 2017-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package embedded.koin.androidx.fragment.koin

import androidx.fragment.app.FragmentFactory
import embedded.koin.androidx.fragment.android.KoinFragmentFactory
import embedded.koin.core.KoinApplication
import embedded.koin.core.module.KoinApplicationDslMarker
import embedded.koin.dsl.module

private val fragmentFactoryModule = module {
    single<FragmentFactory> { KoinFragmentFactory() }
}

/**
 * Setup the KoinFragmentFactory instance
 */

fun KoinApplication.fragmentFactory() {
    koin.loadModules(listOf(fragmentFactoryModule))
}
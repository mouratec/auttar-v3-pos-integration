package embedded.koin.androidx.scope

import androidx.lifecycle.ViewModel
import embedded.koin.core.annotation.KoinExperimentalAPI
import embedded.koin.core.component.KoinScopeComponent
import embedded.koin.core.component.createScope
import embedded.koin.core.scope.Scope

/**
 * Class to help support Koin Scope in a ViewModel
 * create directly a scope instance for current ViewModel
 *
 * allow to intercept before scope closing with `onCloseScope`, to be overriden
 *
 * Destroy linked scope with `onCleared`
 *
 * @author Arnaud Giuliani
 */
abstract class ScopeViewModel : ViewModel(), KoinScopeComponent {

    override val scope: Scope = createScope(this)

    /**
     * To override to add behavior before closing Scope
     */
    open fun onCloseScope(){}

    override fun onCleared() {
        super.onCleared()
        onCloseScope()
        scope.close()
    }
}